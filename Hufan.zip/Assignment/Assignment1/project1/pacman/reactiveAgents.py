# reactiveAgents.py
# ---------------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).

from game import Directions
from game import Agent
from game import Actions
import util
import time
import search

class NaiveAgent(Agent):
    "An agent that goes West until it can't."

    def getAction(self, state):
        "The agent receives a GameState (defined in pacman.py)."
        sense = state.getPacmanSensor()
        if sense[7]:
            return Directions.STOP
        else:
            return Directions.WEST

class PSAgent(Agent):
    "An agent that follows the boundary using production system."

    def getAction(self, state):
        sense = state.getPacmanSensor()
        "Use the production system in lecture notes"
        if sense[0] and sense[7] and not sense[1] and not sense[2]:
        	return Directions.NORTH
        if sense[5] and sense[6] and not sense[0] and not sense[7]:
        	return Directions.WEST
        if sense[3] and sense[4] and not sense[5] and not sense[6]:
        	return Directions.SOUTH
        if sense[1] and sense[2] and not sense[3] and not sense[4]:
        	return Directions.EAST
        return Directions.NORTH

class ECAgent(Agent):
    "An agent that follows the boundary using error-correction."

    def getAction(self, state):
        sense = state.getPacmanSensor()
        "Use error-correction procedure"
        pN = (1.9999, -2.5001, -2.5001, 0, 0, 0, 0, 0.9999, 0.9999)
        pS = (0, 0, 0, 0.9999, 1.9999, -2.5001, -2.5001, 0, 0.9999)
        pE = (0, 0.9999, 1.9999, -2.5001, -2.5001, 0, 0, 0, 0.9999)
        pW = (-2.5001, 0, 0, 0, 0, 0.9999, 1.9999, -2.5001, 0.9999)
        sumN = 0
        sumE = 0
        sumS = 0
        sumW = 0
        for i in range(8):
            sumN += sense[i]*pN[i]
            sumE += sense[i]*pE[i]
            sumS += sense[i]*pS[i]
            sumW += sense[i]*pW[i]
        if sumN > pN[8]:
            return Directions.NORTH
        if sumE > pE[8]:
            return Directions.EAST
        if sumS > pS[8]:
            return Directions.SOUTH
        if sumW > pW[8]:
            return Directions.WEST
        return Directions.NORTH
