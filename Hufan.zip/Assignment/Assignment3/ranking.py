from z3 import *

# the rank of four students in range [1, 4]
Lisa = Int('Lisa')
Bob = Int('Bob')
Jim = Int('Jim')
Mary = Int('Mary')

# whether they are bio major: 1 for yes; 0 for no
LisaMB = Bool('LisaMB')
BobMB = Bool('BobMB')
JimMB = Bool('JimMB')
MaryMB = Bool('MaryMB') 

s = Solver()
 
# The rank of one student must be in range of [1,4]
s.add(Lisa<=4, Lisa>=1) 
s.add(Mary<=4, Mary>=1) 
s.add(Bob<=4, Bob>=1) 
s.add(Jim<=4, Jim>=1)

# 1. Lisa is not next to Bob in the ranking
s.add(Lisa != Bob-1, Lisa != Bob+1)

# 2. Jim is ranked immediately ahead of a biology major
s.add(Or(Jim == Lisa-1, Jim == Bob-1, Jim == Mary-1))

# 3. Bob is ranked immediately ahead of Jim
s.add(Bob == Jim-1)

# 4. One of the women (Lisa and Mary) is a biology major
s.add(Or(LisaMB==True, MaryMB==True))

# 5. One of the women is ranked first
s.add(Or(Lisa==1, Mary==1))

# no one share the same rank
s.add(Not(Or(Lisa == Bob, Lisa == Jim, Lisa == Mary, 
	Bob == Jim, Bob == Mary, Jim == Mary)))

print(s.check())
print(s.model())

'''
Output:
sat
[Jim = 3, Mary = 1, Lisa = 2, Bob = 4]

'''